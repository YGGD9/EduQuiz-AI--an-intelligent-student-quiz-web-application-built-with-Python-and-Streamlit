# main.py

import streamlit as st
from quiz_engine import get_question, check_answer, get_total_questions, questions

st.set_page_config(page_title="EduQuiz AI", layout="centered")
st.markdown("<h1 style='text-align: center;'>🎓 EduQuiz AI: Smart Student Quiz</h1>", unsafe_allow_html=True)

# Initialize session state
if "student_name" not in st.session_state:
    st.session_state.student_name = ""
if "subject" not in st.session_state:
    st.session_state.subject = ""
if "total_quiz" not in st.session_state:
    st.session_state.total_quiz = 0
if "question_index" not in st.session_state:
    st.session_state.question_index = 0
if "score" not in st.session_state:
    st.session_state.score = 0
if "quiz_over" not in st.session_state:
    st.session_state.quiz_over = False

# Home Page: Student name, subject, and quiz count
if not st.session_state.student_name or not st.session_state.subject or st.session_state.total_quiz == 0:
    st.subheader("👤 Enter Student Details")
    st.session_state.student_name = st.text_input("Student Name:")

    st.subheader("📚 Select a Subject")
    st.session_state.subject = st.selectbox("Choose one:", ["Mathematics", "Science", "English", "ICT", "Health", "Common Knowledge", "IQ"])

    st.subheader("🔢 Select Number of Questions")
    quiz_count = st.selectbox("How many questions?", [5, 10, 20])

    if st.button("Start Quiz"):
        st.session_state.total_quiz = quiz_count
        st.session_state.question_index = 0
        st.session_state.score = 0
        st.session_state.quiz_over = False
        st.rerun()

else:
    subject = st.session_state.subject
    name = st.session_state.student_name
    q_index = st.session_state.question_index
    total_available = len(questions[subject])
    total = min(st.session_state.total_quiz, total_available)

    if not st.session_state.quiz_over:
        st.markdown(f"**🧠 {name}, Question {q_index + 1} of {total}**")
        question = get_question(subject, q_index)
        st.info(question)

        answer = st.text_input("✍️ Your Answer:", key=q_index)

        if st.button("✅ Submit", key=f"submit_{q_index}"):
            correct = questions[subject][q_index]["answer"]
            if check_answer(subject, q_index, answer):
                st.success("✅ Correct!")
                st.session_state.score += 1
            else:
                st.error(f"❌ Incorrect. The correct answer is: **{correct}**")
            st.session_state.question_index += 1

            if st.session_state.question_index >= total:
                st.session_state.quiz_over = True
                st.balloons()
            st.rerun()
    else:
        score = st.session_state.score
        st.success(f"🎉 Well done, {name}! You finished the quiz.")
        st.markdown(f"### 🏁 Final Score: **{score} / {total}**")

        if score == total:
            st.success("🌟 Perfect score!")
        elif score >= total / 2:
            st.info("👍 Good effort!")
        else:
            st.warning("📘 Keep practicing! You can do better.")

        if st.button("🔄 Restart Quiz"):
            st.session_state.student_name = ""
            st.session_state.subject = ""
            st.session_state.total_quiz = 0
            st.session_state.question_index = 0
            st.session_state.score = 0
            st.session_state.quiz_over = False
            st.rerun()
