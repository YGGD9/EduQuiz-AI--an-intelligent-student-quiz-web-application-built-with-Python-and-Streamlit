# quiz_engine.py

questions = {
    "Mathematics": [
        {"question": "What is 7 + 5?", "answer": "12"},
        {"question": "What is 9 x 3?", "answer": "27"},
        {"question": "Square root of 81?", "answer": "9"},
        {"question": "What is 100 ÷ 4?", "answer": "25"},
        {"question": "10^2 = ?", "answer": "100"},
    ],
    "Science": [
        {"question": "What gas do humans breathe in?", "answer": "oxygen"},
        {"question": "Water boils at what temperature (°C)?", "answer": "100"},
        {"question": "What planet is closest to the sun?", "answer": "mercury"},
        {"question": "What part of the body pumps blood?", "answer": "heart"},
        {"question": "Photosynthesis occurs in which plant part?", "answer": "leaves"},
    ],
    "English": [
        {"question": "Past tense of 'write'?", "answer": "wrote"},
        {"question": "Synonym of 'angry'?", "answer": "mad"},
        {"question": "Opposite of 'cold'?", "answer": "hot"},
        {"question": "Plural of 'child'?", "answer": "children"},
        {"question": "Adjective in 'The red car'?", "answer": "red"},
    ],
    "ICT": [
        {"question": "What does 'CPU' stand for?", "answer": "central processing unit"},
        {"question": "Binary of 2?", "answer": "10"},
        {"question": "What is the brain of the computer?", "answer": "cpu"},
        {"question": "Full form of HTML?", "answer": "hypertext markup language"},
        {"question": "Common input device?", "answer": "keyboard"},
    ],
    "Health": [
        {"question": "How many hours of sleep do adults need?", "answer": "8"},
        {"question": "What vitamin do we get from sunlight?", "answer": "vitamin d"},
        {"question": "Healthy food: Apple or Chips?", "answer": "apple"},
        {"question": "What organ pumps blood?", "answer": "heart"},
        {"question": "How many glasses of water per day?", "answer": "8"},
    ],
    "Common Knowledge": [
        {"question": "How many continents are there?", "answer": "7"},
        {"question": "What color is the sky?", "answer": "blue"},
        {"question": "Which animal barks?", "answer": "dog"},
        {"question": "First month of the year?", "answer": "january"},
        {"question": "What is the capital of France?", "answer": "paris"},
    ],
    "IQ": [
        {"question": "What comes next: 2, 4, 6, ?", "answer": "8"},
        {"question": "If A=1, B=2, what is C?", "answer": "3"},
        {"question": "Which is the odd one out: Apple, Banana, Carrot?", "answer": "carrot"},
        {"question": "5 + 3 = ?", "answer": "8"},
        {"question": "Mirror of 'b' is?", "answer": "d"},
    ]
}

def get_question(subject, index):
    return questions[subject][index]["question"]

def check_answer(subject, index, user_answer):
    correct = questions[subject][index]["answer"].lower()
    return user_answer.lower().strip() == correct

def get_total_questions(subject):
    return len(questions[subject])
